"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import BrandSelect from "@/components/BrandSelect";
import CampaignControls from "@/components/CampaignControls";
import OverviewKpis from "@/components/OverviewKpis";
import TopInfluencers from "@/components/Topinfluencers";
import UserMenu from "@/components/UserMenu";

export default function OverviewPage() {
  const { data: session, status } = useSession();
  
  // Default to your existing brand; BrandSelect will update it
  const [brandId, setBrandId] = useState<string>("2112f8f1-bb7d-4690-a6ef-2a710db405f4");

  // Controlled by CampaignControls
  const [params, setParams] = useState<{ campaignId: string | null; from: string; to: string }>({
    campaignId: null,
    from: "2025-03-01",
    to: "2025-07-01",
  });

  // When brand changes, reset dates so CampaignControls re-pulls campaign defaults
  useEffect(() => {
    setParams((p) => ({ ...p, campaignId: null }));
  }, [brandId]);

  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-slate-500">Loading...</div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-slate-500">Access denied. Redirecting to sign in...</div>
      </div>
    );
  }

  return (
    <main className="mx-auto max-w-6xl px-6 py-10">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-3xl font-semibold">Overview</h1>
        <UserMenu />
      </div>

      <div className="flex flex-col md:flex-row md:items-end md:gap-6">
        <BrandSelect value={brandId} onChange={(id) => setBrandId(id)} />
        <div className="flex-1">
          <CampaignControls
            brandId={brandId}
            initialFrom={params.from}
            initialTo={params.to}
            onChange={(p) => setParams(p)}
          />
        </div>
      </div>

      {params.from && params.to ? (
        <>
          <OverviewKpis brandId={brandId} from={params.from} to={params.to} />
          <TopInfluencers brandId={brandId} from={params.from} to={params.to} />
        </>
      ) : (
        <div className="text-sm text-slate-500">Choose a brand and campaign.</div>
      )}
    </main>
  );
}