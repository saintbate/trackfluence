import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { auth } from "@/auth";

// Defensive env checks
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error("Missing required environment variables: NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
}

const supabase = createClient(
  SUPABASE_URL || "",
  SUPABASE_SERVICE_ROLE_KEY || ""
);

type GA4OrderData = {
  brand_id: string;
  influencer_id?: string;
  discount_code?: string;
  order_number: string;
  order_date: string;
  total_gross: number;
  influencer_spend?: number;
  campaign_id?: string;
  // GA4 specific fields
  transaction_id?: string;
  utm_campaign?: string;
  utm_source?: string;
  utm_medium?: string;
};

function validateOrderData(data: any): string | null {
  if (!data.brand_id || typeof data.brand_id !== "string") {
    return "brand_id is required";
  }
  
  if (!data.influencer_id && !data.discount_code) {
    return "Either influencer_id or discount_code is required";
  }
  
  // GA4 may send transaction_id instead of order_number
  const orderNumber = data.order_number || data.transaction_id;
  if (!orderNumber || typeof orderNumber !== "string") {
    return "order_number or transaction_id is required";
  }
  
  if (!data.order_date || typeof data.order_date !== "string") {
    return "order_date is required (YYYY-MM-DD format)";
  }
  
  if (data.total_gross === undefined || data.total_gross === null || typeof data.total_gross !== "number") {
    return "total_gross is required and must be a number";
  }
  
  return null;
}

async function resolveInfluencerId(
  discountCode: string,
  utmSource?: string,
  utmCampaign?: string
): Promise<string | null> {
  // Try multiple strategies to find influencer
  
  // Strategy 1: Exact discount code match in handle
  if (discountCode) {
    const { data } = await supabase
      .from("influencer")
      .select("id")
      .ilike("handle", `%${discountCode}%`)
      .limit(1);

    if (data && data.length > 0) {
      return data[0].id;
    }
  }

  // Strategy 2: Match utm_source or utm_campaign
  if (utmSource) {
    const { data } = await supabase
      .from("influencer")
      .select("id")
      .ilike("handle", `%${utmSource}%`)
      .limit(1);

    if (data && data.length > 0) {
      return data[0].id;
    }
  }

  if (utmCampaign) {
    const { data } = await supabase
      .from("influencer")
      .select("id")
      .ilike("name", `%${utmCampaign}%`)
      .limit(1);

    if (data && data.length > 0) {
      return data[0].id;
    }
  }

  return null;
}

export async function POST(req: Request) {
  // Check env vars at runtime
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return NextResponse.json(
      { error: "Server configuration error: missing required environment variables" },
      { status: 500 }
    );
  }

  // Get session for authentication
  const session = await auth();
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    
    // Support both single object and array of objects
    const orders = Array.isArray(body) ? body : [body];
    
    if (orders.length === 0) {
      return NextResponse.json({ error: "No orders provided" }, { status: 400 });
    }

    let inserted = 0;
    let updated = 0;
    const errors: string[] = [];

    for (const orderData of orders) {
      // Validate required fields
      const validationError = validateOrderData(orderData);
      if (validationError) {
        const orderNum = orderData.order_number || orderData.transaction_id || "unknown";
        errors.push(`Order ${orderNum}: ${validationError}`);
        continue;
      }

      // Normalize order_number (GA4 might send as transaction_id)
      const orderNumber = orderData.order_number || orderData.transaction_id;

      let influencerId = orderData.influencer_id;

      // If no influencer_id, try to resolve from discount_code or UTM parameters
      if (!influencerId) {
        influencerId = await resolveInfluencerId(
          orderData.discount_code,
          orderData.utm_source,
          orderData.utm_campaign
        );
        
        if (!influencerId) {
          const identifiers = [
            orderData.discount_code,
            orderData.utm_source,
            orderData.utm_campaign
          ].filter(Boolean).join(", ");
          
          errors.push(`Order ${orderNumber}: Could not resolve influencer from: ${identifiers || "no identifiers"}`);
          continue;
        }
      }

      // Check if order already exists (for upsert)
      const { data: existing } = await supabase
        .from("shop_order")
        .select("id")
        .eq("brand_id", orderData.brand_id)
        .eq("order_number", orderNumber)
        .single();

      const orderRecord = {
        brand_id: orderData.brand_id,
        campaign_id: orderData.campaign_id || null,
        influencer_id: influencerId,
        order_number: orderNumber,
        order_date: orderData.order_date,
        revenue: orderData.total_gross,
        influencer_spend: orderData.influencer_spend || null,
        discount_code: orderData.discount_code || null,
        utm_source: orderData.utm_source || null,
        utm_medium: orderData.utm_medium || null,
        utm_campaign: orderData.utm_campaign || null,
      };

      if (existing) {
        // Update existing order
        const { error } = await supabase
          .from("shop_order")
          .update(orderRecord)
          .eq("id", existing.id);

        if (error) {
          errors.push(`Order ${orderNumber}: Update failed - ${error.message}`);
        } else {
          updated++;
        }
      } else {
        // Insert new order
        const { error } = await supabase
          .from("shop_order")
          .insert({
            id: crypto.randomUUID(),
            ...orderRecord,
          });

        if (error) {
          errors.push(`Order ${orderNumber}: Insert failed - ${error.message}`);
        } else {
          inserted++;
        }
      }
    }

    return NextResponse.json({
      success: true,
      inserted,
      updated,
      total: orders.length,
      errors: errors.length > 0 ? errors : undefined,
    }, { status: errors.length === orders.length ? 400 : 200 });

  } catch (error) {
    console.error("Error in POST /api/ingest/ga4:", error);
    return NextResponse.json(
      { error: "Failed to process GA4 orders" },
      { status: 500 }
    );
  }
}


