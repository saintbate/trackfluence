import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { auth } from "@/auth";

// Defensive env checks
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error("Missing required environment variables: NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
}

const supabase = createClient(
  SUPABASE_URL || "",
  SUPABASE_SERVICE_ROLE_KEY || ""
);

type ShopifyOrderData = {
  brand_id: string;
  influencer_id?: string;
  discount_code?: string;
  order_number: string;
  order_date: string;
  total_gross: number;
  influencer_spend?: number;
  campaign_id?: string;
};

function validateOrderData(data: any): string | null {
  if (!data.brand_id || typeof data.brand_id !== "string") {
    return "brand_id is required";
  }
  
  if (!data.influencer_id && !data.discount_code) {
    return "Either influencer_id or discount_code is required";
  }
  
  if (!data.order_number || typeof data.order_number !== "string") {
    return "order_number is required";
  }
  
  if (!data.order_date || typeof data.order_date !== "string") {
    return "order_date is required (YYYY-MM-DD format)";
  }
  
  if (data.total_gross === undefined || data.total_gross === null || typeof data.total_gross !== "number") {
    return "total_gross is required and must be a number";
  }
  
  return null;
}

async function resolveInfluencerId(
  discountCode: string,
  brandId: string
): Promise<string | null> {
  // Look up influencer by discount code
  const { data, error } = await supabase
    .from("influencer")
    .select("id")
    .ilike("handle", `%${discountCode}%`)
    .limit(1);

  if (error || !data || data.length === 0) {
    return null;
  }

  return data[0].id;
}

export async function POST(req: Request) {
  // Check env vars at runtime
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return NextResponse.json(
      { error: "Server configuration error: missing required environment variables" },
      { status: 500 }
    );
  }

  // Get session for authentication
  const session = await auth();
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    
    // Support both single object and array of objects
    const orders = Array.isArray(body) ? body : [body];
    
    if (orders.length === 0) {
      return NextResponse.json({ error: "No orders provided" }, { status: 400 });
    }

    let inserted = 0;
    let updated = 0;
    const errors: string[] = [];

    for (const orderData of orders) {
      // Validate required fields
      const validationError = validateOrderData(orderData);
      if (validationError) {
        errors.push(`Order ${orderData.order_number || "unknown"}: ${validationError}`);
        continue;
      }

      let influencerId = orderData.influencer_id;

      // If discount_code provided but no influencer_id, try to resolve it
      if (!influencerId && orderData.discount_code) {
        influencerId = await resolveInfluencerId(orderData.discount_code, orderData.brand_id);
        if (!influencerId) {
          errors.push(`Order ${orderData.order_number}: Could not resolve influencer from discount code "${orderData.discount_code}"`);
          continue;
        }
      }

      // Check if order already exists (for upsert)
      const { data: existing } = await supabase
        .from("shop_order")
        .select("id")
        .eq("brand_id", orderData.brand_id)
        .eq("order_number", orderData.order_number)
        .single();

      const orderRecord = {
        brand_id: orderData.brand_id,
        campaign_id: orderData.campaign_id || null,
        influencer_id: influencerId,
        order_number: orderData.order_number,
        order_date: orderData.order_date,
        revenue: orderData.total_gross,
        influencer_spend: orderData.influencer_spend || null,
        discount_code: orderData.discount_code || null,
      };

      if (existing) {
        // Update existing order
        const { error } = await supabase
          .from("shop_order")
          .update(orderRecord)
          .eq("id", existing.id);

        if (error) {
          errors.push(`Order ${orderData.order_number}: Update failed - ${error.message}`);
        } else {
          updated++;
        }
      } else {
        // Insert new order
        const { error } = await supabase
          .from("shop_order")
          .insert({
            id: crypto.randomUUID(),
            ...orderRecord,
          });

        if (error) {
          errors.push(`Order ${orderData.order_number}: Insert failed - ${error.message}`);
        } else {
          inserted++;
        }
      }
    }

    return NextResponse.json({
      success: true,
      inserted,
      updated,
      total: orders.length,
      errors: errors.length > 0 ? errors : undefined,
    }, { status: errors.length === orders.length ? 400 : 200 });

  } catch (error) {
    console.error("Error in POST /api/ingest/shopify:", error);
    return NextResponse.json(
      { error: "Failed to process Shopify orders" },
      { status: 500 }
    );
  }
}


