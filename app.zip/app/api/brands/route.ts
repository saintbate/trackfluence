import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { auth } from "@/auth";

// Defensive env checks
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error("Missing required environment variables: NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
}

const supabase = createClient(
  SUPABASE_URL || "",
  SUPABASE_SERVICE_ROLE_KEY || ""
);

export async function GET() {
  // Check env vars at runtime
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return NextResponse.json(
      { error: "Server configuration error: missing required environment variables" },
      { status: 500 }
    );
  }
  const { data, error } = await supabase
    .from("brand")
    .select("id,name")
    .order("name", { ascending: true });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ brands: data });
}

export async function POST(req: Request) {
  // Check env vars at runtime
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return NextResponse.json(
      { error: "Server configuration error: missing required environment variables" },
      { status: 500 }
    );
  }

  // Get session
  const session = await auth();
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, shop_domain, timezone } = body;

    if (!name || typeof name !== "string" || name.trim().length === 0) {
      return NextResponse.json({ error: "Brand name is required" }, { status: 400 });
    }

    // Generate a unique ID for the brand
    const brandId = crypto.randomUUID();

    // Insert brand with owner_user_id (using email as user identifier)
    const { error: brandError } = await supabase
      .from("brand")
      .insert({
        id: brandId,
        name: name.trim(),
        shop_domain: shop_domain?.trim() || null,
        timezone: timezone || "UTC",
        owner_user_id: session.user.email, // Store email as owner identifier
      });

    if (brandError) {
      console.error("Error creating brand:", brandError);
      return NextResponse.json({ error: brandError.message }, { status: 500 });
    }

    // Create starter campaign spanning today to +30 days
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + 30);

    const startDate = today.toISOString().split("T")[0];
    const endDate = futureDate.toISOString().split("T")[0];
    const campaignId = crypto.randomUUID();

    const { error: campaignError } = await supabase
      .from("campaign")
      .insert({
        id: campaignId,
        brand_id: brandId,
        name: "Starter Campaign",
        start_date: startDate,
        end_date: endDate,
      });

    if (campaignError) {
      console.error("Error creating starter campaign:", campaignError);
      // Don't fail the whole request if campaign creation fails
      // The brand was created successfully
    }

    return NextResponse.json({ 
      brandId, 
      campaignId,
      message: "Brand created successfully" 
    }, { status: 201 });

  } catch (error) {
    console.error("Error in POST /api/brands:", error);
    return NextResponse.json(
      { error: "Failed to create brand" },
      { status: 500 }
    );
  }
}