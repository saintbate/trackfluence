import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { createClient } from "@supabase/supabase-js";

// Initialize Supabase
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

const supabase = createClient(
  SUPABASE_URL || "",
  SUPABASE_SERVICE_ROLE_KEY || ""
);

export async function GET() {
  try {
    // Check authentication
    const session = await auth();
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userEmail = session.user.email;

    // Get user tier from database
    const { data: user, error } = await supabase
      .from("app_user")
      .select("tier, subscription_status, subscription_current_period_end")
      .eq("id", userEmail)
      .single();

    if (error && error.code !== "PGRST116") {
      // PGRST116 is "not found" - that's okay, user is FREE tier
      console.error("Error fetching user tier:", error);
      return NextResponse.json({ error: "Failed to fetch user status" }, { status: 500 });
    }

    // Return user tier (default to FREE if not found)
    return NextResponse.json({
      tier: user?.tier || "FREE",
      subscription_status: user?.subscription_status || null,
      subscription_current_period_end: user?.subscription_current_period_end || null,
    });
  } catch (error: any) {
    console.error("Error in billing status:", error);
    return NextResponse.json(
      { error: "Failed to fetch billing status" },
      { status: 500 }
    );
  }
}


