import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

// Defensive env checks
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error("Missing required environment variables: NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
}

const supabase = createClient(
  SUPABASE_URL || "",
  SUPABASE_SERVICE_ROLE_KEY || ""
);

export async function GET(req: Request) {
  // Check env vars at runtime
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return NextResponse.json(
      { error: "Server configuration error: missing required environment variables" },
      { status: 500 }
    );
  }
  const url = new URL(req.url);
  const brandId = url.searchParams.get("brandId");
  const from = url.searchParams.get("from");
  const to   = url.searchParams.get("to");

  if (!brandId || !from || !to) {
    return NextResponse.json({ error: "brandId, from, to required" }, { status: 400 });
  }

  const { data: overview, error: ovErr } = await supabase.rpc("overview_metrics", {
    p_brand_id: brandId,
    p_from: from,
    p_to: to
  });

  const { data: top, error: topErr } = await supabase.rpc("top_influencers", {
    p_brand_id: brandId,
    p_from: from,
    p_to: to
  });

  if (ovErr || topErr) {
    return NextResponse.json({ error: ovErr?.message || topErr?.message }, { status: 500 });
  }

  return NextResponse.json({ overview, top });
}