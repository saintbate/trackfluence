import { NextResponse } from "next/server";

/**
 * Health check endpoint
 * 
 * Used by monitoring systems, load balancers, and deployment platforms
 * to verify the application is running and responding to requests.
 * 
 * Returns:
 * - ok: true (always, if endpoint responds)
 * - ts: Current timestamp in milliseconds
 */
export async function GET() {
  return NextResponse.json({
    ok: true,
    ts: Date.now(),
  });
}


